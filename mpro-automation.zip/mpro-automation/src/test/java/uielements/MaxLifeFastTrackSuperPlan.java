package uielements;

public class MaxLifeFastTrackSuperPlan {

}
