package uielements;

public class MaxLifeCancerInsurancePlan {

}
