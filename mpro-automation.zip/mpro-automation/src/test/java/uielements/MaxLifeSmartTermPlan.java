package uielements;

public class MaxLifeSmartTermPlan extends ReusableActions {

}
