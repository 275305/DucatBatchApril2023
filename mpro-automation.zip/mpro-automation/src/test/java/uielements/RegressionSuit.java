package uielements;

public class RegressionSuit extends ReusableActions {


}
