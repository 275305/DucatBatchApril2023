package uielements;

public class MaxLifeSavingsAdvantagePlan {

}
