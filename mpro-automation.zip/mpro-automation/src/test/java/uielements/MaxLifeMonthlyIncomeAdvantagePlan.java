package uielements;

public class MaxLifeMonthlyIncomeAdvantagePlan extends ReusableActions {

}
