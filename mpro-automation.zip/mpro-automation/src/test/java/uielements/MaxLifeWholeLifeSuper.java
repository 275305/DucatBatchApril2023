package uielements;

public class MaxLifeWholeLifeSuper extends ReusableActions {

}
