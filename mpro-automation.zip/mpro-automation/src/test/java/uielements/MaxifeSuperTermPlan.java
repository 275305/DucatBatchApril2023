package uielements;

public class MaxifeSuperTermPlan extends ReusableActions {

}
