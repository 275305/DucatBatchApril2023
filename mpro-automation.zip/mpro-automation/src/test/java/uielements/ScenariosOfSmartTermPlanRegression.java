package uielements;

public class ScenariosOfSmartTermPlanRegression {

}
