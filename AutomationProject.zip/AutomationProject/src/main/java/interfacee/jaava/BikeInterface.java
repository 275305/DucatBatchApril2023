package interfacee.jaava;



public interface BikeInterface extends CarInterface
{
	 public void bikeInterface();	

}
