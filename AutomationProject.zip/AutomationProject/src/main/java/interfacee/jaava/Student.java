package interfacee.jaava;

public interface Student {
	
	
	public void studentName();
	
	
	
	

}
