package interfacee.jaava;

public interface CarInterface {
	
	
	public void carInterface();
	

}
