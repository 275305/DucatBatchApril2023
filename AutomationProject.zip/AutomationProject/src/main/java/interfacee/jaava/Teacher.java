package interfacee.jaava;

public interface Teacher {
	
	public void teacherName();

}
