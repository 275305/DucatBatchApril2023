

public class Fruit {
	
	
	
	public void fruit() {
		System.out.println(" This is Fruit class");
	}

}
