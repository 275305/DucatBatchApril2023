package duc.april;

public class TestAbstract extends Salary {

	
		
	public static void main(String[] args) {
		
		//TestAbstract test=new TestAbstract();
		
		//test.empSalary(700);
	

	}

	

}

