package duc.april;

public abstract class Salary {
	
	 int empSal=100;
	
	
	public void empSalary(int empSal) {
		
		this.empSal=empSal;
		
		System.out.println(empSal);
		
	}
	
	
	
	
	

}
