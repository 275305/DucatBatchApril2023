package duc.april;

public interface Employee3{
	
	 int empidd=500;
	
	
	
	public  void empName();



		

	


}
