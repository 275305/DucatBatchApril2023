package duc.april;

public class College {
	
	
	
	
	private String fileName;
	private String ofiiceRecordName;
	

	
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileName() {
		return fileName;
	}
	
	public void setOfiiceRecordName(String ofiiceRecordName) {
		this.ofiiceRecordName = ofiiceRecordName;
	}
	public String getOfiiceRecordName() {
		return ofiiceRecordName;
	}
	
	
	
	
	

}
