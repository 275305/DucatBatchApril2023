package duc.april;

public class StringLateral {
	
	
	public static void main(String[] args) {
		
		/*String s1="India";
		     
		    s1.concat("Bharat");*/
		    
		StringBuffer str1=new StringBuffer("India");    
		    str1.append("Bharat");
		    
		    
		    System.out.println(str1);
		    
		    
		    //System.out.println(s1);
		
		
		
		
	}

}
