package duc.april;

public class Mayank {
	
	
	public  void empName() {
		System.out.println("This is Mayank class");
	}
	
	public static void main(String[] args) {
		
	}               

}
