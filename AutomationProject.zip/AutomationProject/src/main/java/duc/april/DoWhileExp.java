package duc.april;

public class DoWhileExp {
	
	
	public static void main(String[] args) {
		
		int n=10;
		
		do {
			 System.out.println(n); // statement
			 n=n+1; // increment
		}while(n>=10);
	
	}
}
