package duc.april;

public class StaticA {
	
	String str="StaticA";

}
