package duc.april;

import org.testng.annotations.Test;

public class StaticB extends StaticA  {
	
	 
	
	@Test
	public void test() {
		
		System.out.println(" This is Static B");
		
	}

}
