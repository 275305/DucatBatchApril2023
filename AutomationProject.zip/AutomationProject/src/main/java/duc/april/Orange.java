package duc.april;

public class Orange extends Apple {
	
	String orangeColor="Orange";
	
	public void orangeMethod() {
		
		System.out.println("This is orange method");
	}
	
	public static void main(String[] args) {
		
		
	/*	Orange o=new Orange();
		o.appleMethod();
		o.fruiteMethod();
		o.orangeMethod();
		System.out.println(o.fruiteName);
		System.out.println(o.appleColor);
		System.out.println(o.orangeColor);*/
		
		
	}

}
