package duc.april;

public class TryAndCatch {
	
	
	public static void main(String[] args) {
		
		
		//int a=10, b=2,c;
		
			
			/*c=a/b;
			
			System.out.println(c);*/
		
	try {
				int arr[]= {10,20,30,40};
		
		for (int i=0;i<=arr.length;i++) {
			
			System.out.println(arr[i]);
		}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
		
		
	}
	

}
