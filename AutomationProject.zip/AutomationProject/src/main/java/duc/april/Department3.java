package duc.april;

public interface Department3 {

}
