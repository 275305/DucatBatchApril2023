package duc.april;

public class TurnaryExmp {
	
	public static void main(String[] args) {
		
		int a=30,b=30;
		
		System.out.println(a>b?a:b);
	}

}
