package duc.april;

public class Department {
	
	
	public void deptName(String deptName) {
		
		System.out.println(" This is department class");
		
	}
	
	
	

}
