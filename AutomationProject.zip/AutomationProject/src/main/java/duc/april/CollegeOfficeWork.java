package duc.april;

public class CollegeOfficeWork {
	
	
	
	public static void main(String[] args) {
		
		
		College c=new College();
		
		
		  c.setFileName("Office file");
		  System.out.println(c.getFileName());
		  
		  c.setOfiiceRecordName("HBTI0003");
		  System.out.println(c.getOfiiceRecordName());
	}

}
