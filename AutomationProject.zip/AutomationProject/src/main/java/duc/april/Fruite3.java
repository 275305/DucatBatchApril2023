package duc.april;

public class Fruite3 {
	
	
	public String fruiteName="Red";
	
	
	public void fruiteMethod() {
		
		System.out.println("This is fruite method");
	}

}
