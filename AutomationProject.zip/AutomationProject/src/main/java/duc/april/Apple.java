package duc.april;

public class Apple{
	
	String appleColor="Green";
	
	public void appleMethod() {
		System.out.println("This is apple method");
	}

}
