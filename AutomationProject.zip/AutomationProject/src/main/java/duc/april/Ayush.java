package duc.april;

public class Ayush {
	
	public Ayush() {
		
		System.out.println("This is constructor");
	}
	
/*	static
	{
		System.out.println(" This is block");
	}
	
	{
		System.out.println(" this is non static");
	}
*/
	

	public static void empName() {
		int b = 20;
		System.out.println(b);
		System.out.println(" I am Ayush");
	}

	public static void main(String[] args) {
		
         System.out.println(" he llo I am Ravi");                
		System.out.println("hello I am Mayank");
		Ayush.empName();
		Ayush s1 = new Ayush();

		  

	
		
	}

}
