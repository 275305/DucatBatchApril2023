package duc.april;

public class Testinterface implements Employee3 {

	int empidd=800;
	
	public void empName() {
		System.out.println(" ");
		
	}
	
	public void empId() {
		System.out.println("");
	}
	
	public static void main(String[] args) {
		
		Testinterface test=new Testinterface();
		System.out.println(Employee3.empidd);
		
		
		
		
		
	}
	

}
