package input.output.filehandling;

import java.util.Scanner;

public class ReadInput {
	
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the value of a:");
		
		 int a=sc.nextInt();
		 
		 System.out.println("value of a is: " +a);
	}

}
