package input.output.filehandling;

import java.util.Scanner;

public class ReadString {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println(" enter the string: ");

		String str = sc.nextLine();

		System.out.println("String value is : " + str);
		   

	}

}
