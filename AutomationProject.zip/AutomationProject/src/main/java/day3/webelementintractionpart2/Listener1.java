package day3.webelementintractionpart2;

import org.testng.annotations.Test;

public class Listener1 {
	
	@Test
	public void empName() {
		
		System.out.println(" Emp name is Pradeep");
		
	}
	
	@Test
	public void empAddress() {
		System.out.println("Emp Address is Sector 18");
		
	}

}
