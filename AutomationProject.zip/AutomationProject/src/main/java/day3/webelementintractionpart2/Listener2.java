package day3.webelementintractionpart2;

import org.testng.annotations.Test;

public class Listener2 {

	
	@Test
	public void empAge() {
		
		System.out.println(" emp age is 32 ");
		
	}
	
	@Test
	public void empCity() {
		System.out.println("Emp city is Gurgaon");
		
	}
	
}
