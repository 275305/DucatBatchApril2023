package overriding.oops;

public class Employee {

}
