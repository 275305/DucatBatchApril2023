package overriding.oops;

public class Department {
	
	

}
