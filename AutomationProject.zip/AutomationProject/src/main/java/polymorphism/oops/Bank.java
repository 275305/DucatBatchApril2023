package polymorphism.oops;

public class Bank {

	public void interestRate( int a) {
		
		System.out.println(a+a);
         
	}

	public void interestSum(int b) {
		
		System.out.println(b+b);

	}

}
