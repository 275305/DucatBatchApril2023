package polymorphism.oops;

public class TestBank {
	
	
	
	public static void main(String[] args) {
		
		HDFC h=new HDFC();
		
		h.interestRate(10);
		h.interestSum(20);
		h.interestSum(20, 20);
	}

}
