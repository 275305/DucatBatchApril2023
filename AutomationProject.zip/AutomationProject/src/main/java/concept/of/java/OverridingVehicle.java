package concept.of.java;

public class OverridingVehicle {
	
	 void engine() {
		
		System.out.println("This is vehicle engine");
	}
	
	

}
