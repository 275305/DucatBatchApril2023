package concept.of.java;

public class MultilevelInheritance {
	
	
	public static void main(String[] args) {
		
		BabyCat babyCat=new BabyCat();
		
		babyCat.bark();
		babyCat.eat();
		babyCat.weep();
		
	}
	

}
