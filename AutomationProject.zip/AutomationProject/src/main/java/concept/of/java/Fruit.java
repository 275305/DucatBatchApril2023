package concept.of.java;

public class Fruit {
	
	
	public void fruit() {
		
		System.out.println("this is fruit class ");
		
	}

}
