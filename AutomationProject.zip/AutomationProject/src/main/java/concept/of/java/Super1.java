package concept.of.java;

public class Super1 {
	
	// constructor in super class
	
	public Super1() {
		System.out.println("This is the Parent class constructor");
	}
	
	
	String habbit="Good habbit";
	
	void name() {
		
		System.out.println("This is name method of Parent class");
	}
	

}
