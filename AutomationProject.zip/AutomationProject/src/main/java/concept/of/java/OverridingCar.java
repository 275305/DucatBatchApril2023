package concept.of.java;


public class OverridingCar extends OverridingVehicle {
	
void engine() {
		
		System.out.println("This is car engine");
	}
	
	

}
