package concept.of.java;

public class HierarchicalInheritance {
	
	public static void main(String[] args) {
		
		
		Dog  dog=new Dog();
		
		dog.eat();
		dog.run();
	}

}
