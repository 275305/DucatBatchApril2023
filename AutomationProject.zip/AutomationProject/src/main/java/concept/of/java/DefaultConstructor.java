package concept.of.java;

public class DefaultConstructor {
	
	public DefaultConstructor() {
		// TODO Auto-generated constructor stub
		
		System.out.println("This is default costructor");
	}
	
	public static void main(String[] args) {
		
		new DefaultConstructor();
		
	}

}
