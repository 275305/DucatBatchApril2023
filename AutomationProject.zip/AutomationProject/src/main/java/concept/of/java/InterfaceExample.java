package concept.of.java;

public interface InterfaceExample {
	
	
	void nameEmp();
	void addressEmp();
		
	

}
