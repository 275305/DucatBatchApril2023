package concept.of.java;

public class Car {
	
	
	// use the concept of method overriding
	
	public void getCarDetails() {
		
		System.out.println(" This is carDetails");
	}

}
