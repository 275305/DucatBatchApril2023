package concept.of.java;

public class Cat extends Animal {

	
	void bark() {
		System.out.println("Cat is barking");
	}
	
}
