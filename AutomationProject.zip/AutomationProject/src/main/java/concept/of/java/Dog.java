package concept.of.java;

public class Dog extends Animal {
	
	
	void run() {
		
		System.out.println("Dog is running fast");
	}

}
