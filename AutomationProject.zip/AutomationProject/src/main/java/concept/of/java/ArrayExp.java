package concept.of.java;

public class ArrayExp {
	
	
	
	
	
	public static void main(String[] args) {
		
		
		int arr[]=new int[5];// declartion 
		             
		int arr1[]= {10,20,30,40};
		
		char arr2[]= {'a','b','c','d'};
		
		String arr3[]= {"Gurgaon","Delhi","Mumbai","Lucknow"};
		
		// 10a 20b 30c 40d
		
		//System.out.println(arr1.length);
		
		
		for (int i=0;i<arr1.length;i++) {
			
			System.out.print(arr1[i]);
			System.out.print(arr2[i]);
			
			System.out.print(" ");
			
		}
		
		
	}

}
