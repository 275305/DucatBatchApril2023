package concept.of.java;

public class SingleInheritance {
	
	public static void main(String[] args) {
		
		Cat cat=new Cat();
		
		cat.bark();
		cat.eat();
	}

}
