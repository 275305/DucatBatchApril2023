package concept.of.java;



public class Apple extends Fruit {
	
	
public void fruit() {
		
		System.out.println("this is apple class ");
		
	}

public static void main(String[] args) {
	 
	Apple a = new Apple();
	
	a.fruit();
}

}
