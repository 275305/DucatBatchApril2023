package concept.of.java;

public class BabyCat extends Cat{

	void weep() {
		 System.out.println("Baby cat is weeping");
		
	}
	
}
