package concept.of.java;

public class ArrayExample {
	
	public static void main(String[] args) {
		/*int arr[]=new int[10];
		
		int arr1[]= {'1','2','3'};
		
		String str[]=new String[10];
		char ch[] = new char[10];
		
		String str1[]= {"ravi","vijay","mohan","scoot"};
		
		for (String name:str1)
		{   System.out.println(name);
			
		}*/
		
		int arr[]= {10,20,30,40,50};
		
		char arr1[]= {'a','b','c','d','e'};
		
		
		for(int i=0;i<5;i++) {
			
			System.out.print(arr[i]);
			System.out.print(arr1[i]);
			
			System.out.print(" ");
			
		}
		
		
		
		
		
		
	}

}
