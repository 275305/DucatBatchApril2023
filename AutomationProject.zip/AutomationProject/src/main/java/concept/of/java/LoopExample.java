package concept.of.java;

public class LoopExample {
	
	public static void main(String[] args) {
		
		//print 1 to 10
		int n=10,k=1;
		
		for(int i=1;i<=10;i++) {
			System.out.print( i);
						
		}
		
		System.out.println("");
		 int j=1;
		 while(j<=10) {
			 
			 
			 System.out.print(j);
			 j=j+1;
		 }
		 
		 System.out.println("");
		 do {
			 
			 System.out.print(k);
			 k=k+1; 
		 } while(k<=10);
		 
	}
	
	

}
