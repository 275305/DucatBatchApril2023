package concept.of.java;

public class Animal {
	
	void eat() {
		System.out.println("Animal eating ");
	}

}
