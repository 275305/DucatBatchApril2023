package concept.of.java;

public class SuperTest {
	
	// super keyword use for access the variable,method,constructor of parent class
	
	
	public static void main(String[] args) {
		
		Super2 s=new Super2();
		   
		  s.emp();
		         
	}

}
