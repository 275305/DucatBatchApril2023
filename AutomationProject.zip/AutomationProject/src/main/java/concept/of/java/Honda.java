package concept.of.java;

public class Honda extends Car {
	
	
	

	public void getCarDetails() {
		
		System.out.println(" This is Honda Details");
		
		
		}
	
	public static void main(String[] args) {
		
		Honda h=new Honda();
		
		h.getCarDetails();
		
	}

}
