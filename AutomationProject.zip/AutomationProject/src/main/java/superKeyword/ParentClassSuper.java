package superKeyword;

public class ParentClassSuper {

	String empName = "Rajveer Singh";
	String empId = "This1001";
	
	public void empAddress() {
		
		System.out.println("Gurgaon is the address");
	}

}
