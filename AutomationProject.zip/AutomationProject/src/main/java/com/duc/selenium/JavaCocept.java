package com.duc.selenium;

public class JavaCocept {
	
	
	public static void main(String[] args) {
		
		
		System.out.println("hello");
	}
	

}
