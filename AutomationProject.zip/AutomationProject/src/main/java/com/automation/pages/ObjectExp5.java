package com.automation.pages;

public class ObjectExp5 {
	
	
	String empName="Pradeep";
	
	String empID="Kellton3245";
	
	
	public static void getEmpDetails() {
		
		System.out.println("Pradeep details");
		
	}
	
	
	public static void main(String[] args) {
		
		   ObjectExp5 obj = new ObjectExp5();  
		   
		   
		   System.out.println(obj.empName);
		   System.out.println(obj.empID);
		   
		   obj.getEmpDetails();
		   
		   
		   
		   
		   
		   
		   
		
	}

}
