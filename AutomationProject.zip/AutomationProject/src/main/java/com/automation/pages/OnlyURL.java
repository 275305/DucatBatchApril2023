package com.automation.pages;

public class OnlyURL {
	/*
	     1. Verify the Title
	     https://automationexercise.com/
		 https://www.inviul.com/
		 https://www.selenium.dev/
		 
		 2.Verify the Farword and backward cmd
		 
				
				*/

}
