package com.automation.pages;

public class JavaExp {
	
   int b=20;
   
   float a=1.3f;
   char c= 'h';
   
  char [] name= {'g','u','r','g','a','o','n'};
  
   double d=10;
   
   void empAddress() {
	   
	   System.out.println(" Gurgaon");
   }
  
  
  
  public static void main(String[] aabcd) {
	  
	    JavaExp s1 = new JavaExp();
	    
	    System.out.println(s1.b);
	  
  }


}
