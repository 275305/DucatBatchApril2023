package com.automation.pages;

public class Parent {
	
	private void m1() {
		
		System.out.println("This is Private method for parent class");
		
	}
	protected void m2() {
		System.out.println("This is protected method for parent class");
	}

}
