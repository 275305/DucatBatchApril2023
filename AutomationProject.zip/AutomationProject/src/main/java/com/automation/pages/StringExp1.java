package com.automation.pages;

public class StringExp1 {

	
	
	public static void main(String[] args) {
		
		//1. String Lateral
		String str1="Gurgaon";
		
		
		//2. by Using new Keyword
		
		String str2=new String("Delhi");
		
		StringBuffer sb=new StringBuffer("Delhi");
		sb.append("Good city");
		
		StringBuilder sbd=new StringBuilder("Lucknow");
		sbd.append("Fine City");
		
		
		
		
	}
}
