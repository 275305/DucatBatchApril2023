package com.automation.pages;

public @interface FindAll {

}
