package com.automation.pages;

public class TestParentChild {
	
	
	public static void main(String[] args) {
		
		 Parent p=new Parent();
		 
		 p.m2();
		
		   Child ch= new Child();
		      ch.m2();
	}

}
