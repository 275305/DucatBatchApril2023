package com.automation.pages;

public class Child extends Parent{
	
	
	
	private void m1() {
		
		System.out.println("This is private method for child class");
	}
	
	protected void m2() {
		System.out.println("This is Protected method for child class ");
	}

}
