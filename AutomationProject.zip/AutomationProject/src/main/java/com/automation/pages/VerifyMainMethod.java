package com.automation.pages;

public class VerifyMainMethod {
	
	public static void main(int args) {
		
		System.out.println("This is int");
		
	}
	
	public static void main(String[] args) {
		System.out.println("This is string");
	}

}
