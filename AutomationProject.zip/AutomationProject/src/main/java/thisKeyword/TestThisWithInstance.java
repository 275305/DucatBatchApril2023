package thisKeyword;

public class TestThisWithInstance {
	
	
	public static void main(String[] args) {
		ThisWithInstance th=new ThisWithInstance("HB1001", "Ravi");
		
		th.display();
		
		
	}

}
