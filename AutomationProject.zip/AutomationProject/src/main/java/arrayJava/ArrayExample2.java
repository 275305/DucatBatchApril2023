package arrayJava;

public class ArrayExample2 {

}
