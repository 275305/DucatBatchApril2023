package JavaBatch1pm;

public class ArrayExample {
	
	
	public static void main(String[] args) {
		
		int i;
		int arr[]= {10,20,30,40,50};
		
		System.out.println(arr[5]);
		
		
		
	}
	

}
