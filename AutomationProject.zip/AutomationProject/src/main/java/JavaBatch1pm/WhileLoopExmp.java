package JavaBatch1pm;

public class WhileLoopExmp {

	
	
	public static void main(String[] args) {
		
		int n=1;
		
		
		while(n<=10) {
			
			System.out.print(n);
			n++;
		}
		
		
	}
}
