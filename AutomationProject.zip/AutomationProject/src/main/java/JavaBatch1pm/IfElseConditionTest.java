package JavaBatch1pm;

public class IfElseConditionTest {
	
	
	
	
	public static void main(String[] args) {
		
		int a=10,b=5,c;
		
		
		/*if(a>b)
			System.out.println(b);
		
		
		
		    System.out.println(a);*/
		
		
		
		if (a>b)
		{ System.out.println(a);
		
		}
		
		else
		{  System.out.println(b);
		    }
		}
		
	

}
