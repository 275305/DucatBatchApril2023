package JavaBatch1pm;

public class StaticBlock {

	
	
	static {
		
		System.out.println(" This is static block ");
		
		
	}
	
	
	public static void main(String[] args) {
		
		System.out.println(" This is main method");
	}
}
