package JavaBatch1pm;

public class DoWhileExp {
	
	
	
	public static void main(String[] args) {
		
		int n=1;
		
		do {
			
			System.out.println(n);
			n++;
			
		}while(n<=10);
		
		
	}

}
