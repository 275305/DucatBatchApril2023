package inheritance.oops;

public class Fruite {
	
	String fruiteColor="Red";
	
	
	
	public void fruiteMethod() {
		
		System.out.println("This is fruite");
	}
	
	

}
