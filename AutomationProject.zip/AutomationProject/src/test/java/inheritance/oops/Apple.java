package inheritance.oops;

public class Apple extends Fruite {

	String appleColor = "Green";

	public void appleMethod() {

		System.out.println("This is apple");
	}

}
