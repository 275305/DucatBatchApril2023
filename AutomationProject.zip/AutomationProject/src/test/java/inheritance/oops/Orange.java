package inheritance.oops;

public class Orange  extends Fruite{
	
	String orangeColor="Orange";
	
	public void orangeMethod() {
		
		System.out.println("This is orange");
	}

}
