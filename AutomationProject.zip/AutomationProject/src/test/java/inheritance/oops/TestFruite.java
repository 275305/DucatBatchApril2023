package inheritance.oops;

public class TestFruite {
	
	
	public static void main(String[] args) {
		
		
		//Fruite f=new Fruite();
		//Apple a=new Apple();
		
		Orange o=new Orange();
		
		
		//System.out.println(o.fruiteColor);
		
		
		/*o.fruiteMethod();
		System.out.println(o.appleColor);
		o.appleMethod();
		o.orangeMethod();
		*/
		
	}

}
