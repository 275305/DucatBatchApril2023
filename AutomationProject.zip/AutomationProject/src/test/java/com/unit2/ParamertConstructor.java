package com.unit2;

public class ParamertConstructor {
	
	
	public ParamertConstructor( String Name) {
		
		System.out.println(" Using Paramerterize contructor is the Name: " +Name);
		
			}
	
	public static void main(String[] args) {
		
		new ParamertConstructor("Rajesh Kumar");
	}

}
