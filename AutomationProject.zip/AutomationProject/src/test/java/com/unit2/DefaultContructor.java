package com.unit2;

public class DefaultContructor {
	
	DefaultContructor() {
		
		System.out.println("This is default contructor");
	}
	
	public static void main(String[] args) {
		new DefaultContructor();
	}
	

}
