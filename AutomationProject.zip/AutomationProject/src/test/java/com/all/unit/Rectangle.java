package com.all.unit;



public class Rectangle {

	public static void main(String[] args) {
		
		System.out.println("this Rectangle class -child");
		
	}
}
