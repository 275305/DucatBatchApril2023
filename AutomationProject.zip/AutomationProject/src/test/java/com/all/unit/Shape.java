package com.all.unit;

import org.testng.annotations.Test;

public class Shape {
	
	
		
	
	
	@Test
	public void m1() {
		System.out.println("this shape class -Parent");
	}
	
	

}
