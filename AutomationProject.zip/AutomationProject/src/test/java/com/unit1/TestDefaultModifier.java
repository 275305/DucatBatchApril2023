package com.unit1;

public class TestDefaultModifier {
	
	public static void main(String[] args) {
		
		//DefaultModifier def=DefaultModifier();
		
	}

}
