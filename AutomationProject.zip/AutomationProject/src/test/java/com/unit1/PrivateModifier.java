package com.unit1;

public class PrivateModifier {
	
	private void privateModi() {
		
		System.out.println("This is private");
		
	}

}
