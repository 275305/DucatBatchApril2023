package com.unit1;

public class DefaultModifier {
	
		
	public void defaultClass() {
		System.out.println(" this is DefaultModifier Testing ");
	}

}
