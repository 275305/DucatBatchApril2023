package com.unit1;

public class FirstProgram {

	public static void main(String[] args) {
		
		System.out.println("This is first program");
		System.out.println("This is fist program");
		System.out.println("This is second program");
	}
}
