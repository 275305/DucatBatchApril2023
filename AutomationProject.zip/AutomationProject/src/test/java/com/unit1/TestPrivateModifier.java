package com.unit1;

public class TestPrivateModifier {
	
	public static void main(String[] args) {
		
		PrivateModifier pri=new PrivateModifier();
		System.out.println("This is Test Private");
	}

}
