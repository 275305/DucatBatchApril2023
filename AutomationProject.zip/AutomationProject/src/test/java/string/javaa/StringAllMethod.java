package string.javaa;

public class StringAllMethod {
	
	
	
	public static void main(String[] args) {
		
		  String s = "    I am learning Java at DataFlair!     ";
		  
		    //It will Returns the length of this string.
		    //System.out.println("The output of s.length() is:= " + s.length());
		  //it will Returns the char value at the specified index.
		    //System.out.println("The output of s.charAt(10) is :=" + s.charAt(10));
		    
		    //System.out.println("The output of s.substring is:= " + s.substring(20)); 
		    
		   // System.out.println("The output of s.substring(5,10) is:= " + s.substring(11, 22));
		   
		    String s1 = "Data";
		    		
		    String s2 = "Data";
		    
		    String s3=new String("Gurgaon");
		    String s4=new String("Gurgaon");
		    System.out.println(s1==s2);// true
		    System.out.println(s3==s4); // false
		    
		    //System.out.println("The output of s1.concat(s2) is " + s1.concat(s2)); 
		   
		   // System.out.println("The output of s.indexOf('D') is :=" + s.indexOf("t"));
		   
		   // System.out.println("The output of s.length() is " + s.length());
		    //System.out.println("The output of s1.equals(s2) is " + s1.equals(s2));
		    
		    
		    
		   /* if(s1==s2)
		    {
		    System.out.println("both string at same place");
		    }
		    else {
		    	System.out.println(" both string at deffrent place");
		    }*/
		    
		   /* System.out.println("The output of s1.compareTo(s2) is " + s2.compareTo(s1));
		    
		    String s3="Hello";
		    String s4="Hello";
		    
		     if (s3==s4) {
		    	 System.out.println("Both are same");
		     }
		     else
		     {
		    	 System.out.println("Both are not same");
		     }*/
		     /*
		        String s5=new String("Hello");
			    String s6=new String ("Hello");
			    
			    if (s5==s6) {
			    	 System.out.println("Both are same");
			     }
			     else
			     {
			    	 System.out.println("Both are not same");
			     }*/
			    
			    
		
	}

}
