package basic.one.pmclass;

public class EmpClass2 {

	
	public void empAddress() {
		
		System.out.println("My address is Bijnaor");
	}
	
	
	
	public static void main(String[] abhay) {
		
		
		EmpClass2 emp = new EmpClass2();
		
		emp.empAddress();
		

	}

}
